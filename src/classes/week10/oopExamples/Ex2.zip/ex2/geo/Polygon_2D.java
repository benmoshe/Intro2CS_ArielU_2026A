package ex2.geo;

public class Polygon_2D implements GeoShape{
	////// add your code here //////

	////////////////////////////////
	public Polygon_2D() {
		////// add your code here //////

		////////////////////////////////
	}
	public Polygon_2D(Polygon_2D po) {
		////// add your code here //////

		////////////////////////////////
	}
	public Point_2D[] getAllPoints() {
		////// add your code here //////

		return null;
		////////////////////////////////
	}

	public void add(Point_2D p) {
		////// add your code here //////

		////////////////////////////////
	}
	@Override
	public String toString()
	{
		////// add your code here //////

		return null;
		////////////////////////////////
	}
	@Override
	public boolean contains(Point_2D ot) {
		////// add your code here //////

		return false;
		////////////////////////////////
	}

	@Override
	public double area() {
		////// add your code here //////

		return -1;
		////////////////////////////////
	}
	@Override
	public double perimeter() {
		////// add your code here //////

		return -1;
		////////////////////////////////
	}
	@Override
	public void translate(Point_2D vec) {
		////// add your code here //////

		////////////////////////////////
	}
	@Override
	public GeoShape copy() {
		////// add your code here //////

		return null;
		////////////////////////////////
	}

	@Override
	public void scale(Point_2D center, double ratio) {
		////// add your code here //////

		////////////////////////////////
	}
	@Override
	public void rotate(Point_2D center, double angleDegrees) {
		////// add your code here //////

		////////////////////////////////
	}

}
